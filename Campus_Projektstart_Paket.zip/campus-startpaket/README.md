# Campus – Projektplanungspaket

Repository: https://github.com/jan-brand/digitale-schule

Dieses Paket enthält **keinen fertigen Anwendungscode**, sondern den Implementierungsauftrag und technischen Projektplan für Campus Foundation v0.1.

## Dateien
- `START_PROMPT.md`: Kopierfertiger Entwicklungsauftrag für Codex/einen Entwicklungsagenten.
- `doc/PROJECT_PLAN.md`: Umfang, Roadmap, priorisiertes Backlog.
- `doc/ARCHITECTURE.md`: React/Expo/Supabase-Architektur, Projektstruktur und UI-Routen.
- `doc/DATA_MODEL.md`: Datenbankentitäten, Integritätsregeln und RLS-Testmatrix.
- `doc/SECURITY.md`: technische Sicherheits- und Datenschutzgates.
- `doc/ACCEPTANCE.md`: überprüfbare Definition of Done und Abnahmetests.

Bewahre die im Repository vorhandene Datei `doc/design.md` bei; sie ist die bestehende Quelle für Campus Purple `#4C1D95`.

## Verwendung
Die Dokumente in das Repository kopieren, einen Feature-Branch erstellen und den Inhalt von `START_PROMPT.md` als Auftrag an den Entwicklungsagenten geben. Ohne ausdrückliche Freigabe keine Änderungen direkt in Produktion durchführen.
